//package com.cg.model.dto.staff;
//
//import com.cg.model.Staff;
//import com.cg.model.Type;
//import com.cg.model.User;
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//import lombok.experimental.Accessors;
//
//import java.math.BigDecimal;
//
//@NoArgsConstructor
//@AllArgsConstructor
//@Getter
//@Setter
//@Accessors(chain = true)
//public class StaffCreResDTO {
//    private long id;
//    private String fullName;
//    private String email;
//    private String phone;
//    private String address;
//
//    public Staff toStaff() {
//        return new Staff()
//                .setId(null)
//                .setFullName(fullName)
//                .setEmail(email)
//                .setPhone(phone)
//                .setAddress(address)
//                ;
//    }
//}
