package com.cg.service.category;

import com.cg.model.Category;
import com.cg.model.Role;
import com.cg.service.IGeneralService;

public interface ICategoryService extends IGeneralService<Category, Long> {
}
