//package com.cg.model.dto.staff;
//
//import com.cg.model.Role;
//import com.cg.model.User;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//import lombok.experimental.Accessors;
//
//@NoArgsConstructor
//@Getter
//@Setter
//@Accessors(chain = true)
//public class StaffDTO {
//    private long id;
//    private String fullName;
//    private String email;
//    private String phone;
//    private String address;
//
//    public StaffDTO(long id, String fullName, String email, String phone, String address) {
//        this.id = id;
//        this.fullName = fullName;
//        this.email = email;
//        this.phone = phone;
//        this.address = address;
//    }
//}
