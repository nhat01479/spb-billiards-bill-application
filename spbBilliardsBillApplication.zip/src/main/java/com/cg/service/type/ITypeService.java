package com.cg.service.type;

import com.cg.service.IGeneralService;
import com.cg.model.Type;

public interface ITypeService extends IGeneralService<Type, Long> {
}
