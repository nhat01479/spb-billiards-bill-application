# spb-billiards-bill-application
# Member: Nguyễn Minh Nhật - Hoàng Văn Nguyên
# Thời gian hoàn thành: tháng 7/2023 (10 ngày)
# Ứng dụng thanh toán hoá đơn quầy billiard
# Hoàn thành chức năng thanh toán, chưa hoàn thành chuyển, tách, gộp bàn
# Tài khoản demo:
- username: admin
- password: admin123
